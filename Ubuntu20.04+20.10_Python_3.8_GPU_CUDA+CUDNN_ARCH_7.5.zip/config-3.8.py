PYTHON_EXTENSIONS_PATHS = [
    os.path.join('/home/arcarc/.virtualenvs/cv/lib/python3.8/site-packages/cv2', 'python-3.8')
] + PYTHON_EXTENSIONS_PATHS
